var total = 0;
var operacao = "";
var valorAtual = 0;
var calculo = "";

function acao(n){
    const visor = document.getElementById("visor"); 
    if(n=="CE"){
        visor.value ="0";
        total = 0;
        valorAtual = 0;
        return 0;
    }
    if(visor.value.includes(".")==true && n=="."){
        return 0;
    }
    
    if(visor.value=="0" && n=="0"){
        return 0;
    }
    if(visor.value=="0"){
        visor.value = "";
    }
    if(visor.value=="" && n=="0") {
        return 0;
    }
    if (n=='apagar') {
        n = visor.value.slice(0, -1)
        visor.value = n;
        if (visor.value==""){
            visor.value = 0;
        }
        return 0;        
    }

    if (n=="-" || n=="+" || n=="*" || n=="/") {
        if (visor.value != 0){
            valorAtual = visor.value;
            valorAtual = parseFloat(valorAtual);
            total = valorAtual;
        }
        operacao = n;
        visor.value = 0;
        return 0;
    }else{
        valorAtual = visor.value;
        calculo = parseFloat(total) + operacao + parseFloat(valorAtual);
        total = parseFloat(calculo)
    }

    if (n=="total"){
        valorAtual = visor.value;
        calculo = parseFloat(total) + operacao + parseFloat(valorAtual)
        total = eval(calculo);
        total = parseFloat(total);
        visor.value = total;
        return 0; 
    }else{
        valorAtual = visor.value;
    }

    visor.value = (visor.value + '' + n);
}