$(document).ready(function(){
    
    alert("A página foi atualizada!")
    
    $('#btCadastro').click (function(){
        var inputNome = $("#txtNome").val();
        var inputIdade = $("#txtIdade").val();
        var inputsexualidade = $("#txtsexualidade").val();
        var inputcor= $("#txtcor").val();
        var inputemail = $("#txtemail").val();
        var selectgenero = $("#cmbgenero").val();

        
        if(inputNome == ""){
            alert("Preencha o nome")
            return 0;
        } else if(inputIdade == ""){
            alert("Preencha a Idade")
        } else if(inputsexualidade == ""){
            alert("Preencha sua Sexualidade")
        } else if(selectgenero == ""){
            alert("Selecione seu gênero")
        } else if(inputemail == ""){
            alert("Preencha seu email")
        } else if(inputcor == "")
            alert("Preencha sua cor Preferida");


        alert("Cadastrado com as seguintes informações: \n Nome: " + inputNome +  "\n Idade: " + inputIdade + "\n Sexualidade: " + inputsexualidade + "\n E-mail: " + inputemail + "\n Cor favorita: " + inputcor + "\n Gênero: "+ selectgenero)
    
    })
});